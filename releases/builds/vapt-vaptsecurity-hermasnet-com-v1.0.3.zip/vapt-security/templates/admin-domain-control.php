<?php
// Superadmin Domain Control Page
// Check transient auth
$user_id = get_current_user_id();
$is_verified = get_transient( 'vapt_auth_' . $user_id );

// License Data
$license = VAPT_License::get_license();
$license_type = $license['type'] ?? 'standard';
$license_expires = $license['expires'] ?? 0;
$license_auto_renew = $license['auto_renew'] ?? false;
$expiry_date = $license_expires ? date_i18n( get_option( 'date_format' ), $license_expires ) : __( 'Never', 'vapt-security' );

// Get Active Features
$features = VAPT_Features::get_active_features();
$all_features = VAPT_Features::get_defined_features();

// Pre-calculate future expiries for JS
$base_time = ! empty( $license['start'] ) ? $license['start'] : time();
$future_expiries = [
    'standard' => date_i18n( get_option( 'date_format' ), $base_time + ( 30 * DAY_IN_SECONDS ) ),
    'pro'      => date_i18n( get_option( 'date_format' ), $base_time + ( 365 * DAY_IN_SECONDS ) ),
    'developer' => __( 'Never', 'vapt-security' ),
    'trial' => date_i18n( get_option( 'date_format' ), $base_time + ( 7 * DAY_IN_SECONDS ) ),
    'demo'  => date_i18n( get_option( 'date_format' ), $base_time + ( 15 * DAY_IN_SECONDS ) ),
];

$csv_names = [
    'rate_limiting'              => 'Lack of Rate Limiting on Contact Form (V#5)',
    'input_validation'           => 'No Input Validation (V#14)',
    'cron_protection'            => 'WordPress Cron Job Vulnerability (DoS) (V#2)',
    'security_logging'           => 'Security Event Logging & Audit Trail',
    'login_protection'           => 'Lack of Rate Limiting on WordPress Login (V#1)',
    'login_enum_protection'      => 'Username Enumeration via wp-login.php (V#8)',
    'xmlrpc_protection'          => 'XML-RPC Leads to Unauthenticated Blind SSRF (V#3)',
    'directory_listing'          => 'Directory Listing Vulnerability (V#4)',
    'banner_grabbing'            => 'Banner Grabbing Vulnerability (V#6)',
    'rest_api_protection'        => 'Username Enumeration via WordPress REST API (V#7/10)',
    'security_headers'           => 'Clickjacking Protection (V#11)',
    'debug_log_protection'       => 'Public Exposure of Debug Log File (V#12)',
    'readme_protection'          => 'Information Disclosure via readme.html (V#13)',
];
?>
<style>
    /* Force Full Width for Domain Admin */
    .vapt-domain-admin-wrap {
        max-width: 100% !important;
        margin-right: 20px !important;
        width: auto !important;
        display: block !important;
    }
    .vapt-domain-admin-wrap .card {
        max-width: none !important;
        width: 100% !important;
        margin: 20px 0 !important;
        box-sizing: border-box !important;
    }
    .vapt-admin-row {
        display: flex;
        gap: 20px;
        width: 100%;
    }
    .vapt-admin-row .card {
        flex: 1;
        margin: 0 !important;
    }
    #wpbody-content {
        padding-bottom: 50px;
    }
    /* Sleek Feature Cards */
    .vapt-feature-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    .vapt-feature-card {
        background: #fff;
        border: 1px solid #e5e5e5;
        border-radius: 8px;
        padding: 20px;
        display: flex;
        flex-direction: column;
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        position: relative;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .vapt-feature-card:hover {
        border-color: #2271b1;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        transform: translateY(-2px);
    }
    .vapt-feature-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 15px;
    }
    .vapt-feature-icon {
        width: 40px;
        height: 40px;
        background: #f0f6fb;
        color: #2271b1;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
    }
    .vapt-feature-card.active .vapt-feature-icon {
        background: #2271b1;
        color: #fff;
    }
    .vapt-feature-info {
        flex: 1;
    }
    .vapt-feature-info h4 {
        margin: 0;
        font-size: 14px;
        font-weight: 600;
        color: #1d2327;
    }
    .vapt-feature-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: auto;
        padding-top: 15px;
        border-top: 1px solid #f0f0f1;
    }
    .vapt-feature-status {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        padding: 2px 8px;
        border-radius: 12px;
        background: #f0f0f1;
        color: #646970;
    }
    .vapt-feature-card.active .vapt-feature-status {
        background: #edfaef;
        color: #008a20;
    }
    .vapt-category-title {
        font-size: 16px;
        font-weight: 600;
        margin: 30px 0 15px 0;
        padding-bottom: 8px;
        border-bottom: 2px solid #f0f0f1;
        display: flex;
        align-items: center;
        gap: 10px;
        color: #1d2327;
    }

    /* Generator Grid Fixes */
    .vapt-generator-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(380px, 1fr));
        gap: 25px;
        margin-top: 15px;
        max-width: 1150px;
    }
    .vapt-generator-table th {
        width: 110px !important;
        min-width: 110px !important;
        padding: 4px 0 !important;
        font-size: 12px;
        vertical-align: middle;
        color: #646970;
    }
    .vapt-generator-table td {
        padding: 4px 0 !important;
    }
    .vapt-generator-table input[type="text"],
    .vapt-generator-table select,
    .vapt-generator-table textarea {
        width: 100% !important;
        font-size: 13px !important;
        padding: 4px 8px !important;
        min-height: 30px !important;
    }
    .vapt-generator-table textarea {
        height: 50px !important;
    }

    /* Build History Table */
    .vapt-build-history {
        margin-top: 30px;
        border-top: 1px solid #ddd;
        padding-top: 20px;
    }
    .vapt-history-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        background: #fff;
        border-radius: 4px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .vapt-history-table th, .vapt-history-table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #eee;
    }
    .vapt-history-table th {
        background: #f8f9fa;
        font-weight: 600;
        color: #1d2327;
        font-size: 13px;
    }
    .vapt-row-suspended td:not(:last-child) {
        opacity: 0.5;
    }
    .vapt-row-suspended {
        background: #f9f9f9;
    }
    .vapt-btn-disabled {
        opacity: 0.4 !important;
        pointer-events: none !important;
        cursor: not-allowed !important;
        filter: grayscale(1);
    }
    .vapt-build-id {
        font-family: monospace;
        background: #f0f0f1;
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 11px;
    }

    /* Tabs Styling */
    .vapt-tabs-nav {
        margin: 20px 0 0 0;
        border-bottom: 1px solid #ccc;
        display: flex;
        gap: 5px;
    }
    .vapt-tab-link {
        padding: 10px 20px;
        background: #e5e5e5;
        border: 1px solid #ccc;
        border-bottom: none;
        cursor: pointer;
        font-weight: 600;
        color: #50575e;
        border-radius: 4px 4px 0 0;
        transition: all 0.2s ease;
        text-decoration: none;
    }
    .vapt-tab-link:hover {
        background: #f0f0f1;
        color: #2271b1;
    }
    .vapt-tab-link.active {
        background: #fff;
        color: #000;
        border-bottom: 1px solid #fff;
        margin-bottom: -1px;
    }
    .vapt-tab-content {
        display: none;
        animation: fadeIn 0.3s ease;
    }
    .vapt-tab-content.active {
        display: block;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(5px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
<div class="wrap vapt-domain-admin-wrap">
    <h1><?php esc_html_e( 'VAPT Security - Domain Admin', 'vapt-security' ); ?></h1>
    
    <?php if ( ! $is_verified ) : ?>
        <!-- OTP Verification (Automated Send) -->
        <div class="vapt-otp-container card" style="max-width: 400px; margin-top: 20px; padding: 20px;">
            <h2><?php esc_html_e( 'Superadmin Authentication', 'vapt-security' ); ?></h2>
            <p><?php esc_html_e( 'Verify your identity to manage Domain Features. An OTP has been sent to your email.', 'vapt-security' ); ?></p>
            
            <div id="vapt-otp-step-2" style="margin-top: 20px;">
                <input type="text" id="vapt-otp-input" class="regular-text" placeholder="------" maxlength="6" style="width: 100%; text-align: center; letter-spacing: 5px;" />
                <button type="button" id="vapt-verify-otp" class="button button-primary button-hero" style="width: 100%; margin-top: 10px;">
                    <?php esc_html_e( 'Verify', 'vapt-security' ); ?>
                </button>
                <div style="margin-top: 10px; text-align: center;">
                    <span id="vapt-otp-timer-container"><?php esc_html_e( 'Resend in', 'vapt-security' ); ?> <span id="vapt-otp-timer">120</span>s</span>
                    <a href="#" id="vapt-resend-otp" style="display:none;"><?php esc_html_e( 'Resend OTP', 'vapt-security' ); ?></a>
                </div>
            </div>
            <div id="vapt-otp-message" style="margin-top: 15px;"></div>
        </div>

    <?php else : 
        // Categorize Features
        $categories = [
            'protection' => [
                'title' => __( 'Critical Protection', 'vapt-security' ),
                'icon'  => 'dashicons-shield-alt',
                'items' => [ 'rate_limiting', 'input_validation', 'cron_protection', 'security_logging' ]
            ],
            'access' => [
                'title' => __( 'Access Control', 'vapt-security' ),
                'icon'  => 'dashicons-lock',
                'items' => [ 'login_protection', 'login_enum_protection', 'xmlrpc_protection', 'rest_api_protection' ]
            ],
            'hardening' => [
                'title' => __( 'System Hardening', 'vapt-security' ),
                'icon'  => 'dashicons-admin-settings',
                'items' => [ 'directory_listing', 'banner_grabbing', 'security_headers', 'debug_log_protection', 'readme_protection' ]
            ],
        ];

        $dashicons = [
            'rate_limiting'         => 'dashicons-performance',
            'input_validation'      => 'dashicons-forms',
            'cron_protection'       => 'dashicons-clock',
            'security_logging'      => 'dashicons-list-view',
            'login_protection'      => 'dashicons-lock',
            'login_enum_protection' => 'dashicons-admin-users',
            'xmlrpc_protection'     => 'dashicons-cloud',
            'rest_api_protection'   => 'dashicons-rest-api',
            'directory_listing'     => 'dashicons-category',
            'banner_grabbing'       => 'dashicons-shield',
            'security_headers'      => 'dashicons-external',
            'debug_log_protection'  => 'dashicons-visibility',
            'readme_protection'     => 'dashicons-media-text',
        ];
    ?>
        <!-- Verified Superadmin UI -->
        
        <div class="vapt-tabs-nav">
            <a href="#vapt-tab-features" class="vapt-tab-link active" data-tab="features"><?php esc_html_e( 'Domain Features', 'vapt-security' ); ?></a>
            <a href="#vapt-tab-generator" class="vapt-tab-link" data-tab="generator"><?php esc_html_e( 'Build Generator', 'vapt-security' ); ?></a>
        </div>

        <!-- Tab Content: Features -->
        <div id="vapt-tab-features" class="vapt-tab-content active">
            <div class="card" style="margin-top: 0; border-top: none; padding: 20px; border-radius: 0 0 4px 4px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <div>
                        <h2 style="margin: 0;"><?php esc_html_e( 'Domain Features', 'vapt-security' ); ?></h2>
                        <p class="description"><?php esc_html_e( 'Enable or disable features for this domain. Disabled features are hidden from Admins.', 'vapt-security' ); ?></p>
                    </div>
                    <button type="button" id="vapt-save-features-top" class="button button-primary button-hero vapt-save-features-btn"><?php esc_html_e( 'Save Changes', 'vapt-security' ); ?></button>
                </div>
                
                <form id="vapt-domain-features-form">
                    <?php foreach ( $categories as $cat_id => $cat ) : ?>
                        <h3 class="vapt-category-title">
                            <span class="dashicons <?php echo esc_attr( $cat['icon'] ); ?>"></span>
                            <?php echo esc_html( $cat['title'] ); ?>
                        </h3>
                        <div class="vapt-feature-grid">
                            <?php foreach( $cat['items'] as $slug ) : 
                                if ( ! isset( $all_features[$slug] ) ) continue;
                                $display_name = isset($csv_names[$slug]) ? $csv_names[$slug] : ucwords( str_replace( '_', ' ', $slug ) );
                                $is_active = VAPT_Features::is_enabled( $slug );
                                $icon = isset($dashicons[$slug]) ? $dashicons[$slug] : 'dashicons-admin-generic';
                            ?>
                            <div class="vapt-feature-card <?php echo $is_active ? 'active' : ''; ?>">
                                <div class="vapt-feature-header">
                                    <div class="vapt-feature-icon">
                                        <span class="dashicons <?php echo esc_attr( $icon ); ?>"></span>
                                    </div>
                                    <div class="vapt-feature-info">
                                        <h4 title="<?php echo esc_attr($display_name); ?>"><?php echo esc_html( $display_name ); ?></h4>
                                    </div>
                                </div>
                                <div class="vapt-feature-footer">
                                    <span class="vapt-feature-status"><?php echo $is_active ? __( 'Active', 'vapt-security' ) : __( 'Inactive', 'vapt-security' ); ?></span>
                                    <label class="switch">
                                        <input type="checkbox" class="vapt-feature-toggle" name="features[<?php echo esc_attr( $slug ); ?>]" value="1" <?php checked( $is_active ); ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                    
                    <p style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #f0f0f1;">
                        <button type="button" class="button button-primary button-hero vapt-save-features-btn"><?php esc_html_e( 'Save Domain Features', 'vapt-security' ); ?></button>
                        <span id="vapt-features-msg" style="margin-left: 15px; font-weight: 500;"></span>
                    </p>
                </form>
            </div>
        </div>

        <!-- Tab Content: Generator -->
        <div id="vapt-tab-generator" class="vapt-tab-content">
            <div class="vapt-admin-row" style="margin-top: 0;">
                <div class="card" style="width: 100%; margin: 0; padding: 20px; border-top: none; border-radius: 0 0 4px 4px;">
                    <h2><?php esc_html_e( 'Locked Configuration Generator', 'vapt-security' ); ?></h2>
                    <p class="description"><?php esc_html_e( 'Generate a portable configuration file locked to a specific domain pattern and customize plugin branding.', 'vapt-security' ); ?></p>
                    
                    <div class="vapt-generator-grid">
                        <!-- Column 1: Core Lock Settings -->
                        <div>
                            <h3 style="margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px; display: flex; align-items: center; gap: 8px;">
                                <span class="dashicons dashicons-lock"></span>
                                <?php esc_html_e( 'Core Lock Settings', 'vapt-security' ); ?>
                            </h3>
                            <table class="form-table vapt-generator-table" style="margin-top: 0;">
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Domain Pattern', 'vapt-security' ); ?></th>
                                    <td>
                                        <input type="text" id="vapt-lock-domain" class="regular-text" placeholder="*.example.com" value="<?php echo esc_attr( $_SERVER['HTTP_HOST'] ); ?>" style="width: 100%;">
                                        <input type="hidden" id="vapt-build-id-tracking" value="">
                                        <p class="description" style="font-size: 11px; margin-top: 5px;"><?php esc_html_e( 'Use * for wildcards (e.g., *.example.com).', 'vapt-security' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Domain Type', 'vapt-security' ); ?></th>
                                    <td>
                                        <select id="vapt-lock-type" style="width: 100%;">
                                            <option value="standard"><?php esc_html_e( 'Standard - Full Match', 'vapt-security' ); ?></option>
                                            <option value="wildcard"><?php esc_html_e( 'Wildcard - Contains Match', 'vapt-security' ); ?></option>
                                            <option value="universal"><?php esc_html_e( 'Universal - Any Domain', 'vapt-security' ); ?></option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'License Type', 'vapt-security' ); ?></th>
                                    <td>
                                        <select id="vapt-lock-license-type" style="width: 100%;">
                                            <option value="trial">Trial (7 days)</option>
                                            <option value="demo">Demo Build (15 days)</option>
                                            <option value="standard" style="font-weight: bold;">Standard (30 days) [Default]</option>
                                            <option value="pro">Pro (365 days)</option>
                                            <option value="developer">Developer/Perpetual (Never)</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Expiry Date', 'vapt-security' ); ?></th>
                                    <td>
                                        <input type="text" id="vapt-lock-license-expiry" value="<?php echo esc_attr( $future_expiries['standard'] ); ?>" readonly class="regular-text" style="width: 100%; background: #f0f0f1;">
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Auto Renewal', 'vapt-security' ); ?></th>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 20px;">
                                            <div style="display: flex; align-items: center; gap: 8px;">
                                                <label class="switch">
                                                    <input type="checkbox" id="vapt-lock-license-auto-renew">
                                                    <span class="slider round"></span>
                                                </label>
                                            </div>
                                            <div style="display: flex; align-items: center; gap: 6px; background: #f0f6fb; padding: 4px 10px; border-radius: 6px; border: 1px solid #d0e2f1;">
                                                <span style="font-weight: 600; font-size: 11px; color: #2271b1; text-transform: uppercase;"><?php esc_html_e( 'Terms Renewed:', 'vapt-security' ); ?></span>
                                                <span id="vapt-lock-renewal-count" style="font-weight: 700; font-size: 13px; color: #1d2327;"><?php echo isset($license['renewal_count']) ? esc_html($license['renewal_count']) : '0'; ?></span>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Settings', 'vapt-security' ); ?></th>
                                    <td>
                                        <label>
                                            <input type="checkbox" id="vapt-lock-include-settings" checked>
                                            <?php esc_html_e( 'Export current configuration', 'vapt-security' ); ?>
                                        </label>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <!-- Column 2: White Labeling -->
                        <div>
                            <h3 style="margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px; display: flex; align-items: center; gap: 8px;">
                                <span class="dashicons dashicons-art"></span>
                                <?php esc_html_e( 'White Labeling', 'vapt-security' ); ?>
                            </h3>
                            <table class="form-table vapt-generator-table" style="margin-top: 0;">
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Plugin Name', 'vapt-security' ); ?></th>
                                    <td>
                                        <input type="text" id="vapt-wl-name" class="regular-text" placeholder="VAPT Security" style="width: 100%;">
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Slug', 'vapt-security' ); ?></th>
                                    <td>
                                        <input type="text" id="vapt-wl-slug" class="regular-text" readonly style="width: 100%; background: #f0f0f1;">
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Author', 'vapt-security' ); ?></th>
                                    <td>
                                        <input type="text" id="vapt-wl-author" class="regular-text" placeholder="Your Name" style="width: 100%;">
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Company', 'vapt-security' ); ?></th>
                                    <td>
                                        <input type="text" id="vapt-wl-company" class="regular-text" placeholder="Your Company" style="width: 100%;">
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Description', 'vapt-security' ); ?></th>
                                    <td>
                                        <textarea id="vapt-wl-description" class="regular-text" style="width: 100%; height: 60px;" placeholder="<?php esc_attr_e( 'Plugin description...', 'vapt-security' ); ?>"></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Build Version', 'vapt-security' ); ?></th>
                                    <td>
                                        <input type="text" id="vapt-wl-version" class="regular-text" value="1.0.0" style="width: 100%;">
                                        <div id="vapt-version-suggestion-wrapper" style="margin-top: 5px; font-size: 11px; display: none;">
                                            <?php esc_html_e( 'Suggested:', 'vapt-security' ); ?> 
                                            <button type="button" id="vapt-version-apply-suggestion" class="button-link" style="font-size: 11px; vertical-align: baseline;"></button>
                                        </div>
                                        <p class="description" style="font-size: 11px; margin-top: 5px;"><?php esc_html_e( 'Track per-domain build versions.', 'vapt-security' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Min WP Version', 'vapt-security' ); ?></th>
                                    <td>
                                        <input type="text" id="vapt-wl-wp-version" class="regular-text" placeholder="5.6" value="5.6" style="width: 100%;">
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php esc_html_e( 'Min PHP Version', 'vapt-security' ); ?></th>
                                    <td>
                                        <input type="text" id="vapt-wl-php-version" class="regular-text" placeholder="7.4" value="7.4" style="width: 100%;">
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee; display: flex; gap: 10px; align-items: center;">
                        <button type="button" id="vapt-generate-locked-config" class="button button-primary" style="height: 40px; padding: 0 20px;"><?php esc_html_e( 'Generate Config File', 'vapt-security' ); ?></button>
                        <button type="button" id="vapt-generate-client-zip" class="button button-secondary" style="height: 40px; padding: 0 20px;">
                            <?php esc_html_e( 'Download Rebranded Zip', 'vapt-security' ); ?>
                        </button>
                        <div id="vapt-generate-msg" style="flex-grow: 1; font-weight: 500;"></div>
                    </div>

                    <!-- Build History Section -->
                    <div class="vapt-build-history">
                        <h3><?php esc_html_e( 'Build History & Logs', 'vapt-security' ); ?></h3>
                        <table class="vapt-history-table" id="vapt-history-table">
                            <thead>
                                    <tr>
                                        <th><?php esc_html_e( 'Build ID', 'vapt-security' ); ?></th>
                                        <th><?php esc_html_e( 'Domain', 'vapt-security' ); ?></th>
                                        <th><?php esc_html_e( 'Type', 'vapt-security' ); ?></th>
                                        <th><?php esc_html_e( 'Plugin Name', 'vapt-security' ); ?></th>
                                        <th><?php esc_html_e( 'Version', 'vapt-security' ); ?></th>
                                        <th><?php esc_html_e( 'License', 'vapt-security' ); ?></th>
                                        <th><?php esc_html_e( 'Date', 'vapt-security' ); ?></th>
                                        <th><?php esc_html_e( 'Expires', 'vapt-security' ); ?></th>
                                        <th><?php esc_html_e( 'Actions', 'vapt-security' ); ?></th>
                                    </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $build_history = get_option( 'vapt_build_history', [] );
                                if ( empty( $build_history ) ) : ?>
                                    <tr class="no-builds">
                                        <td colspan="9" style="text-align: center; color: #999; padding: 30px;">
                                            <?php esc_html_e( 'No builds generated yet.', 'vapt-security' ); ?>
                                        </td>
                                    </tr>
                                <?php else : 
                                    // Show last 10 builds
                                    $history = array_reverse( $build_history );
                                    $history = array_slice( $history, 0, 10 );
                                    foreach ( $history as $build ) : 
                                        $filename = !empty($build['filename']) ? $build['filename'] : '';
                                        if ( empty($filename) ) {
                                            // Fallback for older logs without filename
                                            $safe_domain = preg_replace( '/[^a-zA-Z0-9\-\.]/', '-', $build['domain'] );
                                            $safe_domain = trim( $safe_domain, '-' );
                                            $filename = ($build['type'] === 'zip') ? "vapt-security-{$safe_domain}.zip" : "vapt-{$safe_domain}-locked-config.php";
                                        }
                                        
                                        $sub_dir = ($build['type'] === 'zip') ? 'releases/builds/' : 'releases/configurations/';
                                        $file_path = plugin_dir_path( __FILE__ ) . '../' . $sub_dir . $filename;
                                        $file_exists = !empty($filename) && file_exists( $file_path );
                                        $download_url = $file_exists ? plugins_url( $sub_dir . $filename, dirname(__FILE__) . '/../vapt-security.php' ) : '';
                                    ?>
                                        <tr class="<?php echo (isset($build['status']) && $build['status'] === 'suspended') ? 'vapt-row-suspended' : ''; ?>">
                                            <td><span class="vapt-build-id"><?php echo esc_html( $build['id'] ); ?></span></td>
                                            <td><?php echo esc_html( $build['domain'] ); ?></td>
                                            <td style="font-size: 11px; text-transform: capitalize; color: #666;"><?php echo esc_html( $build['domain_type'] ?? 'standard' ); ?></td>
                                            <td><?php echo esc_html( $build['name'] ); ?></td>
                                            <td><?php echo esc_html( $build['version'] ); ?></td>
                                            <td><span class="badge" style="background: #2271b1; color: #fff; padding: 2px 8px; border-radius: 10px; font-size: 10px;"><?php echo esc_html( strtoupper($build['license']) ); ?></span></td>
                                            <td style="font-size: 11px; color: #666;"><?php echo esc_html( date_i18n( get_option( 'date_format' ), $build['time'] ) ); ?></td>
                                            <td style="font-size: 11px; color: #666;">
                                                <?php 
                                                    if ( empty($build['expires']) || $build['license'] === 'developer' ) {
                                                        echo esc_html__( 'Never', 'vapt-security' );
                                                    } else {
                                                        echo esc_html( date_i18n( get_option( 'date_format' ), $build['expires'] ) );
                                                    }
                                                ?>
                                            </td>
                                            <td style="display: flex; gap: 5px; align-items: center;">
                                                <?php 
                                                $is_suspended = (isset($build['status']) && $build['status'] === 'suspended');
                                                $disabled_class = $is_suspended ? ' vapt-btn-disabled' : '';
                                                ?>
                                                <?php if ( $file_exists ) : ?>
                                                    <a href="<?php echo esc_url( $download_url ); ?>" class="button button-small<?php echo $disabled_class; ?>" download title="<?php echo ($build['type'] === 'zip') ? esc_attr__( 'Download ZIP Package', 'vapt-security' ) : esc_attr__( 'Download Config File', 'vapt-security' ); ?>" style="padding: 0 6px;">
                                                        <span class="dashicons <?php echo ($build['type'] === 'zip') ? 'dashicons-archive' : 'dashicons-download'; ?>" style="font-size: 16px; width: 16px; height: 16px; line-height: 16px; margin-top: 3px;"></span>
                                                    </a>
                                                <?php endif; ?>
                                                <button type="button" class="button button-small vapt-edit-build<?php echo $disabled_class; ?>" 
                                                    data-id="<?php echo esc_attr($build['id']); ?>" 
                                                    data-domain="<?php echo esc_attr($build['domain']); ?>"
                                                    data-domain-type="<?php echo esc_attr($build['domain_type'] ?? 'standard'); ?>"
                                                    data-license-type="<?php echo esc_attr($build['license']); ?>"
                                                    data-name="<?php echo esc_attr($build['name']); ?>"
                                                    data-version="<?php echo esc_attr($build['version']); ?>"
                                                    data-author="<?php echo esc_attr($build['white_label']['author'] ?? ''); ?>"
                                                    data-company="<?php echo esc_attr($build['white_label']['company'] ?? ''); ?>"
                                                    data-desc="<?php echo esc_attr($build['white_label']['description'] ?? ''); ?>"
                                                    data-wp="<?php echo esc_attr($build['white_label']['requires_at_least'] ?? '5.6'); ?>"
                                                    data-php="<?php echo esc_attr($build['white_label']['requires_php'] ?? '7.4'); ?>"
                                                    title="<?php esc_attr_e( 'Edit/Reuse settings', 'vapt-security' ); ?>" style="padding: 0 6px;">
                                                    <span class="dashicons dashicons-edit" style="font-size: 16px; width: 16px; height: 16px; line-height: 16px; margin-top: 3px;"></span>
                                                </button>

                                                <div class="vapt-action-group" style="display: flex; gap: 2px; border-left: 1px solid #eee; padding-left: 5px; margin-left: 2px;">
                                                    <?php if ( $is_suspended ) : ?>
                                                        <button type="button" class="button button-small vapt-suspend-build" 
                                                            data-id="<?php echo esc_attr($build['id']); ?>" 
                                                            data-status="suspended"
                                                            style="color: #2271b1; padding: 0 6px;" 
                                                            title="<?php esc_attr_e( 'Resume Build', 'vapt-security' ); ?>">
                                                            <span class="dashicons dashicons-undo" style="font-size: 16px; width: 16px; height: 16px; line-height: 16px; margin-top: 3px;"></span>
                                                        </button>
                                                        <button type="button" class="button button-small vapt-delete-build" 
                                                            data-id="<?php echo esc_attr($build['id']); ?>" 
                                                            style="color: #d63638; padding: 0 6px;" 
                                                            title="<?php esc_attr_e( 'Purge Record', 'vapt-security' ); ?>">
                                                            <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px; line-height: 16px; margin-top: 3px;"></span>
                                                        </button>
                                                    <?php else : ?>
                                                        <button type="button" class="button button-small vapt-suspend-build" 
                                                            data-id="<?php echo esc_attr($build['id']); ?>" 
                                                            data-status="active"
                                                            style="color: #46b450; padding: 0 6px;" 
                                                            title="<?php esc_attr_e( 'Suspend Build', 'vapt-security' ); ?>">
                                                            <span class="dashicons dashicons-lock" style="font-size: 16px; width: 16px; height: 16px; line-height: 16px; margin-top: 3px;"></span>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach;
                                endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    let timerInterval;

    function startOtpTimer() {
        let timeLeft = 120;
        $('#vapt-otp-timer').text(timeLeft);
        $('#vapt-otp-timer-container').show();
        $('#vapt-resend-otp').hide();
        
        clearInterval(timerInterval);
        timerInterval = setInterval(function() {
            timeLeft--;
            $('#vapt-otp-timer').text(timeLeft);
            if(timeLeft <= 0) {
                clearInterval(timerInterval);
                $('#vapt-otp-timer-container').hide();
                $('#vapt-resend-otp').show();
            }
        }, 1000);
    }

    // Auto-send OTP on load if not verified
    function autoSendOtp() {
        $.post(ajaxurl, {action:'vapt_send_otp'}, function(r){
            if(r.success) {
                $('#vapt-otp-message').html('<span style="color:green">'+r.data.message+'</span>');
                startOtpTimer();
            } else {
                $('#vapt-otp-message').html('<span style="color:red">'+r.data.message+'</span>');
            }
        });
    }

    if ($('#vapt-otp-input').length > 0) {
        autoSendOtp();
    }

    // Resend Logic
    $('#vapt-resend-otp').click(function(e){
        e.preventDefault();
        
        // Disable buttons temporarily
        $(this).prop('disabled', true);
        
        $.post(ajaxurl, {action:'vapt_send_otp'}, function(r){
             // Re-enable (for send btn)
            $('#vapt-send-otp').prop('disabled', false);

            if(r.success) {
                $('#vapt-otp-step-1').hide();
                $('#vapt-otp-step-2').show();
                $('#vapt-otp-message').html('<span style="color:green">'+r.data.message+'</span>');
                startOtpTimer();
            } else {
                $('#vapt-otp-message').html('<span style="color:red">'+r.data.message+'</span>');
            }
        });
    });

    $('#vapt-verify-otp').click(function(){
        $.post(ajaxurl, {
            action:'vapt_verify_otp', 
            otp: $('#vapt-otp-input').val()
        }, function(r){
            if(r.success) location.reload();
            else $('#vapt-otp-message').html('<span style="color:red">'+r.data.message+'</span>');
        });
    });

    // Tab Switching Logic
    $('.vapt-tab-link').click(function(e){
        e.preventDefault();
        var tabId = $(this).data('tab');
        
        $('.vapt-tab-link').removeClass('active');
        $(this).addClass('active');
        
        $('.vapt-tab-content').removeClass('active');
        $('#vapt-tab-' + tabId).addClass('active');
        
        // Update URL hash for persistence on reload
        window.location.hash = 'tab-' + tabId;
    });

    // Persistence on reload
    if(window.location.hash) {
        var hashTab = window.location.hash.replace('#tab-', '');
        $('.vapt-tab-link[data-tab="' + hashTab + '"]').click();
    }

    // Save Features
    $('.vapt-save-features-btn').click(function(){
        var btn = $(this);
        var originalText = btn.text();
        btn.prop('disabled', true).text('<?php esc_html_e( 'Saving...', 'vapt-security' ); ?>');
        
        var data = $('#vapt-domain-features-form').serialize();
        $.post(ajaxurl, {
            action: 'vapt_save_domain_features',
            data: data
        }, function(r){
            btn.prop('disabled', false).text(originalText);
            if(r.success) {
                $('#vapt-features-msg').html('<span style="color:green">'+r.data.message+'</span>');
                setTimeout(function(){ $('#vapt-features-msg').fadeOut(); }, 3000);
            }
            else $('#vapt-features-msg').html('<span style="color:red">'+r.data.message+'</span>');
        });
    });

    // Real-time visual feedback for toggles
    $('.vapt-feature-toggle').change(function(){
        var card = $(this).closest('.vapt-feature-card');
        var status = card.find('.vapt-feature-status');
        if($(this).is(':checked')) {
            card.addClass('active');
            status.text('<?php echo esc_js( __( 'Active', 'vapt-security' ) ); ?>');
        } else {
            card.removeClass('active');
            status.text('<?php echo esc_js( __( 'Inactive', 'vapt-security' ) ); ?>');
        }
    });

    // Locked Config Generator
    // Real-time Expiry and License Type logic for the Generator
    var futureExpiries = <?php echo json_encode( $future_expiries ); ?>;

    $('#vapt-lock-license-type').change(function(){
        var type = $(this).val();
        if ( futureExpiries[type] ) {
            $('#vapt-lock-license-expiry').val( futureExpiries[type] );
        }
        
        // Developer/Universal Constraint
        if ( type === 'developer' ) {
            $('#vapt-lock-license-auto-renew').prop('checked', false).prop('disabled', true);
        } else {
            $('#vapt-lock-license-auto-renew').prop('disabled', false);
        }
    });

    // Domain Type logic
    $('#vapt-lock-type').change(function(){
        var type = $(this).val();
        if (type === 'universal') {
            $('#vapt-lock-domain').val('*').prop('disabled', true).css('background', '#f0f0f1');
        } else {
            $('#vapt-lock-domain').prop('disabled', false).css('background', '#fff');
            if ($('#vapt-lock-domain').val() === '*') {
                $('#vapt-lock-domain').val('<?php echo esc_attr( $_SERVER['HTTP_HOST'] ); ?>');
            }
        }
    });

    // Version suggestion logic
    function suggestNextVersion(current) {
        if (!current) return 'v1.0.0';
        var hasV = current.charAt(0).toLowerCase() === 'v';
        var version = hasV ? current.substring(1) : current;
        
        if (!version.match(/^\d+\.\d+\.\d+$/)) return hasV ? 'v1.0.0' : '1.0.0';
        
        var parts = version.split('.').map(Number);
        parts[2]++; // Default to patch bump
        return (hasV ? 'v' : '') + parts.join('.');
    }

    function updateVersionSuggestion(version) {
        if (version) {
            var next = suggestNextVersion(version);
            $('#vapt-version-apply-suggestion').text(next);
            $('#vapt-version-suggestion-wrapper').show();
        } else {
            $('#vapt-version-suggestion-wrapper').hide();
        }
    }

    $('#vapt-version-apply-suggestion').click(function() {
        var next = $(this).text();
        $('#vapt-wl-version').val(next);
        updateVersionSuggestion(next);
    });

    $('#vapt-lock-domain').on('change blur', function() {
        var domain = $(this).val();
        if (!domain || domain === '*') return;
        
        $.post(ajaxurl, {
            action: 'vapt_get_last_build_version',
            domain: domain,
            nonce: '<?php echo wp_create_nonce( "vapt_locked_config" ); ?>'
        }, function(r) {
            if (r.success && r.data.version) {
                updateVersionSuggestion(r.data.version);
            } else {
                updateVersionSuggestion('1.0.0');
            }
        });
    }).trigger('blur');

    $('#vapt-wl-version').on('input', function() {
        updateVersionSuggestion($(this).val());
    });

    $('#vapt-wl-name').on('input', function() {
        var name = $(this).val();
        var slug = name.toLowerCase()
            .replace(/[^\w\s-]/g, '') // Remove non-word chars
            .replace(/\s+/g, '-')     // Replace spaces with -
            .replace(/-+/g, '-')      // Replace multiple - with single -
            .trim();
        $('#vapt-wl-slug').val(slug);
    });

    $('#vapt-generate-locked-config').click(function(){
        var btn = $(this);
        var originalText = btn.text();
        btn.prop('disabled', true).text('<?php esc_html_e( 'Generating...', 'vapt-security' ); ?>');
        
        $.post(ajaxurl, {
            action: 'vapt_generate_locked_config',
            edit_id: $('#vapt-build-id-tracking').val(),
            domain: $('#vapt-lock-domain').val(),
            domain_type: $('#vapt-lock-type').val(),
            license_type: $('#vapt-lock-license-type').val(),
            auto_renew: $('#vapt-lock-license-auto-renew').is(':checked') ? 1 : 0,
            include_settings: $('#vapt-lock-include-settings').is(':checked') ? 1 : 0,
            wl_name: $('#vapt-wl-name').val(),
            wl_slug: $('#vapt-wl-slug').val(),
            wl_description: $('#vapt-wl-description').val(),
            wl_author: $('#vapt-wl-author').val(),
            wl_company: $('#vapt-wl-company').val(),
            wl_version: $('#vapt-wl-version').val(),
            wl_wp_version: $('#vapt-wl-wp-version').val(),
            wl_php_version: $('#vapt-wl-php-version').val(),
            nonce: '<?php echo wp_create_nonce( "vapt_locked_config" ); ?>'
        }, function(r){
            btn.prop('disabled', false).text(originalText);
            if(r.success) {
                $('#vapt-generate-msg').html('<span style="color:green">'+r.data.message+'</span>');
                setTimeout(function(){ location.reload(); }, 1500);
            } else {
                $('#vapt-generate-msg').html('<span style="color:red">'+r.data.message+'</span>');
            }
        });
    });

    $('#vapt-generate-client-zip').click(function(){
        var btn = $(this);
        var originalText = btn.text();
        btn.prop('disabled', true).text('<?php esc_html_e( 'Building Zip...', 'vapt-security' ); ?>');
        
        $.post(ajaxurl, {
            action: 'vapt_generate_client_zip',
            edit_id: $('#vapt-build-id-tracking').val(),
            domain: $('#vapt-lock-domain').val(),
            domain_type: $('#vapt-lock-type').val(),
            license_type: $('#vapt-lock-license-type').val(),
            auto_renew: $('#vapt-lock-license-auto-renew').is(':checked') ? 1 : 0,
            include_settings: $('#vapt-lock-include-settings').is(':checked') ? 1 : 0,
            wl_name: $('#vapt-wl-name').val(),
            wl_slug: $('#vapt-wl-slug').val(),
            wl_description: $('#vapt-wl-description').val(),
            wl_author: $('#vapt-wl-author').val(),
            wl_company: $('#vapt-wl-company').val(),
            wl_version: $('#vapt-wl-version').val(),
            wl_wp_version: $('#vapt-wl-wp-version').val(),
            wl_php_version: $('#vapt-wl-php-version').val(),
            nonce: '<?php echo wp_create_nonce( "vapt_locked_config" ); ?>'
        }, function(r){
            btn.prop('disabled', false).text(originalText);
            if(r.success) {
                $('#vapt-generate-msg').html('<span style="color:green">'+r.data.message+'</span>');
                setTimeout(function(){ location.reload(); }, 1500);
            } else {
                $('#vapt-generate-msg').html('<span style="color:red">'+r.data.message+'</span>');
            }
        });
    });
    // Edit/Reuse Build Settings
    $(document).on('click', '.vapt-edit-build', function(){
        var btn = $(this);
        $('#vapt-build-id-tracking').val(btn.data('id')); // Track ID for update
        $('#vapt-lock-domain').val(btn.data('domain')).trigger('change');
        $('#vapt-lock-type').val(btn.data('domain-type')).trigger('change');
        $('#vapt-lock-license-type').val(btn.data('license-type')).trigger('change');
        
        $('#vapt-wl-name').val(btn.data('name')).trigger('input');
        $('#vapt-wl-author').val(btn.data('author'));
        $('#vapt-wl-company').val(btn.data('company'));
        $('#vapt-wl-description').val(btn.data('desc'));
        $('#vapt-wl-version').val(btn.data('version')).trigger('input');
        $('#vapt-wl-wp-version').val(btn.data('wp'));
        $('#vapt-wl-php-version').val(btn.data('php'));
        
        // Scroll to top of generator
        $('html, body').animate({
            scrollTop: $("#vapt-tab-generator").offset().top - 100
        }, 500);
        
        // Visual feedback
        $('#vapt-generate-msg').html('<span style="color:blue"><?php esc_html_e( 'Settings loaded into generator.', 'vapt-security' ); ?></span>').fadeIn();
        setTimeout(function(){ $('#vapt-generate-msg').fadeOut(); }, 3000);
    });

    // Suspend/Resume Build
    $(document).on('click', '.vapt-suspend-build', function(){
        var btn = $(this);
        var id = btn.data('id');
        var currentStatus = btn.data('status');
        var actionText = (currentStatus === 'suspended') ? 'resume' : 'suspend';
        
        if(!confirm('<?php echo esc_js( __( 'Are you sure you want to ', 'vapt-security' ) ); ?>' + actionText + '<?php echo esc_js( __( ' this build?', 'vapt-security' ) ); ?>')) return;
        
        btn.prop('disabled', true).css('opacity', '0.5');
        
        $.post(ajaxurl, {
            action: 'vapt_toggle_build_status',
            id: id,
            nonce: '<?php echo wp_create_nonce( "vapt_locked_config" ); ?>'
        }, function(r){
            btn.prop('disabled', false).css('opacity', '1');
            if(r.success) {
                var tr = btn.closest('tr');
                var downloadBtn = tr.find('a.button-small');
                var editBtn = tr.find('.vapt-edit-build');
                
                if(r.data.status === 'suspended') {
                    tr.addClass('vapt-row-suspended');
                    btn.data('status', 'suspended');
                    btn.attr('title', '<?php echo esc_js( __( 'Resume Build', 'vapt-security' ) ); ?>');
                    btn.find('.dashicons').removeClass('dashicons-lock').addClass('dashicons-undo');
                    btn.css('color', '#2271b1');
                    
                    // Add Purge button if it doesn't exist
                    if (tr.find('.vapt-delete-build').length === 0) {
                        var purgeBtn = $('<button type="button" class="button button-small vapt-delete-build" data-id="' + id + '" style="color: #d63638; padding: 0 6px;" title="<?php esc_attr_e( 'Purge Record', 'vapt-security' ); ?>"><span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px; line-height: 16px; margin-top: 3px;"></span></button>');
                        btn.after(purgeBtn);
                    }
                    
                    downloadBtn.addClass('vapt-btn-disabled');
                    editBtn.addClass('vapt-btn-disabled');
                } else {
                    tr.removeClass('vapt-row-suspended');
                    btn.data('status', 'active');
                    btn.attr('title', '<?php echo esc_js( __( 'Suspend Build', 'vapt-security' ) ); ?>');
                    btn.find('.dashicons').removeClass('dashicons-undo').addClass('dashicons-lock');
                    btn.css('color', '#46b450');
                    
                    // Remove Purge button
                    tr.find('.vapt-delete-build').remove();
                    
                    downloadBtn.removeClass('vapt-btn-disabled');
                    editBtn.removeClass('vapt-btn-disabled');
                }
            } else {
                alert(r.data.message || 'Error toggling status');
            }
        });
    });

    // Delete Build from History (Purge)
    $(document).on('click', '.vapt-delete-build', function(){
        if(!confirm('<?php echo esc_js( __( 'Are you sure you want to PURGE this build record? This cannot be undone.', 'vapt-security' ) ); ?>')) return;
        
        var btn = $(this);
        var id = btn.data('id');
        
        btn.prop('disabled', true).css('opacity', '0.5');
        
        $.post(ajaxurl, {
            action: 'vapt_delete_build',
            id: id,
            nonce: '<?php echo wp_create_nonce( "vapt_locked_config" ); ?>'
        }, function(r){
            if(r.success) {
                btn.closest('tr').fadeOut(function(){ 
                    $(this).remove(); 
                    if($('#vapt-history-table tbody tr').length === 0) {
                        $('#vapt-history-table tbody').append('<tr class="no-builds"><td colspan="9" style="text-align: center; color: #999; padding: 30px;"><?php esc_html_e( 'No builds generated yet.', 'vapt-security' ); ?></td></tr>');
                    }
                });
            } else {
                btn.prop('disabled', false).css('opacity', '1');
                alert(r.data.message || 'Error purging record');
            }
        });
    });
});
</script>
