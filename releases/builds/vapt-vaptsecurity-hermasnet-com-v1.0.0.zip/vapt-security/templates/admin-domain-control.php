<?php
// Superadmin Domain Control Page
// Check transient auth
$user_id = get_current_user_id();
$is_verified = get_transient( 'vapt_auth_' . $user_id );

// License Data
$license = VAPT_License::get_license();
$license_type = $license['type'] ?? 'standard';
$license_expires = $license['expires'] ?? 0;
$license_auto_renew = $license['auto_renew'] ?? false;
$expiry_date = $license_expires ? date_i18n( get_option( 'date_format' ), $license_expires ) : __( 'Never', 'vapt-security' );

// Get Active Features
$features = VAPT_Features::get_active_features();
$all_features = VAPT_Features::get_defined_features();

// Pre-calculate future expiries for JS
$base_time = ! empty( $license['start'] ) ? $license['start'] : time();
$future_expiries = [
    'standard' => date_i18n( get_option( 'date_format' ), $base_time + ( 30 * DAY_IN_SECONDS ) ),
    'pro'      => date_i18n( get_option( 'date_format' ), $base_time + ( 365 * DAY_IN_SECONDS ) ),
    'developer' => __( 'Never', 'vapt-security' ),
    'trial' => date_i18n( get_option( 'date_format' ), $base_time + ( 7 * DAY_IN_SECONDS ) ),
    'demo'  => date_i18n( get_option( 'date_format' ), $base_time + ( 15 * DAY_IN_SECONDS ) ),
];

$csv_names = [
    'rate_limiting'              => 'Lack of Rate Limiting on Contact Form (V#5)',
    'input_validation'           => 'No Input Validation (V#14)',
    'cron_protection'            => 'WordPress Cron Job Vulnerability (DoS) (V#2)',
    'security_logging'           => 'Security Event Logging & Audit Trail',
    'login_protection'           => 'Lack of Rate Limiting on WordPress Login (V#1)',
    'login_enum_protection'      => 'Username Enumeration via wp-login.php (V#8)',
    'xmlrpc_protection'          => 'XML-RPC Leads to Unauthenticated Blind SSRF (V#3)',
    'directory_listing'          => 'Directory Listing Vulnerability (V#4)',
    'banner_grabbing'            => 'Banner Grabbing Vulnerability (V#6)',
    'rest_api_protection'        => 'Username Enumeration via WordPress REST API (V#7/10)',
    'security_headers'           => 'Clickjacking Protection (V#11)',
    'debug_log_protection'       => 'Public Exposure of Debug Log File (V#12)',
    'readme_protection'          => 'Information Disclosure via readme.html (V#13)',
];
?>
<style>
    /* Force Full Width for Domain Admin */
    .vapt-domain-admin-wrap {
        max-width: 100% !important;
        margin-right: 20px !important;
        width: auto !important;
        display: block !important;
    }
    .vapt-domain-admin-wrap .card {
        max-width: none !important;
        width: 100% !important;
        margin: 20px 0 !important;
        box-sizing: border-box !important;
    }
    .vapt-admin-row {
        display: flex;
        gap: 20px;
        width: 100%;
    }
    .vapt-admin-row .card {
        flex: 1;
        margin: 0 !important;
    }
    #wpbody-content {
        padding-bottom: 50px;
    }
    .vapt-feature-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        margin-bottom: 20px;
        width: 100%;
        box-sizing: border-box;
    }
    .vapt-feature-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #f9f9f9;
        border: 1px solid #ccd0d4;
        padding: 12px 15px;
        border-radius: 4px;
        position: relative;
        min-height: 50px;
    }
    .vapt-feature-item h4 {
        margin: 0;
        font-size: 13px;
        font-weight: 600;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        flex: 1;
        padding-right: 10px;
        cursor: help;
    }
    .vapt-feature-item:hover h4 {
        white-space: normal;
        overflow: visible;
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        background: #fff;
        z-index: 100;
        padding: 12px 15px;
        border: 1px solid #2271b1;
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        min-height: 100%;
        display: flex;
        align-items: center;
    }
    .vapt-feature-item input[type="checkbox"] {
        margin: 0;
        flex-shrink: 0;
        z-index: 5;
    }
</style>
<div class="wrap vapt-domain-admin-wrap">
    <h1><?php esc_html_e( 'VAPT Security - Domain Admin', 'vapt-security' ); ?></h1>
    
    <?php if ( ! $is_verified ) : ?>
        <!-- OTP Verification (Automated Send) -->
        <div class="vapt-otp-container card" style="max-width: 400px; margin-top: 20px; padding: 20px;">
            <h2><?php esc_html_e( 'Superadmin Authentication', 'vapt-security' ); ?></h2>
            <p><?php esc_html_e( 'Verify your identity to manage Domain Features. An OTP has been sent to your email.', 'vapt-security' ); ?></p>
            
            <div id="vapt-otp-step-2" style="margin-top: 20px;">
                <input type="text" id="vapt-otp-input" class="regular-text" placeholder="------" maxlength="6" style="width: 100%; text-align: center; letter-spacing: 5px;" />
                <button type="button" id="vapt-verify-otp" class="button button-primary button-hero" style="width: 100%; margin-top: 10px;">
                    <?php esc_html_e( 'Verify', 'vapt-security' ); ?>
                </button>
                <div style="margin-top: 10px; text-align: center;">
                    <span id="vapt-otp-timer-container"><?php esc_html_e( 'Resend in', 'vapt-security' ); ?> <span id="vapt-otp-timer">120</span>s</span>
                    <a href="#" id="vapt-resend-otp" style="display:none;"><?php esc_html_e( 'Resend OTP', 'vapt-security' ); ?></a>
                </div>
            </div>
            <div id="vapt-otp-message" style="margin-top: 15px;"></div>
        </div>

    <?php else : ?>
        <!-- Verified Superadmin UI -->
        
        <!-- Domain Features -->
        <div class="card" style="margin-top: 20px; padding: 20px;">
            <h2><?php esc_html_e( 'Domain Features', 'vapt-security' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Enable or disable features for this domain. Disabled features are hidden from Admins.', 'vapt-security' ); ?></p>
            
            <style>
                .vapt-feature-grid {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 20px;
                    margin-bottom: 20px;
                    width: 100%;
                    box-sizing: border-box;
                }
                .vapt-feature-item {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    background: #f9f9f9;
                    border: 1px solid #ccd0d4;
                    padding: 12px 15px;
                    border-radius: 4px;
                    position: relative;
                    min-height: 50px;
                }
                .vapt-feature-item h4 {
                    margin: 0;
                    font-size: 13px;
                    font-weight: 600;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    flex: 1;
                    padding-right: 10px;
                    cursor: help;
                }
                .vapt-feature-item:hover h4 {
                    white-space: normal;
                    overflow: visible;
                    position: absolute;
                    left: 0;
                    top: 0;
                    width: 100%;
                    background: #fff;
                    z-index: 100;
                    padding: 12px 15px;
                    border: 1px solid #2271b1;
                    border-radius: 4px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                    min-height: 100%;
                    display: flex;
                    align-items: center;
                }
                .vapt-feature-item input[type="checkbox"] {
                    margin: 0;
                    flex-shrink: 0;
                    z-index: 5;
                }
            </style>
            
            <form id="vapt-domain-features-form">
                <?php if ( count($all_features) > 5 ) : ?>
                    <!-- Grid Layout for many features -->
                    <div class="vapt-feature-grid">
                        <?php foreach( $all_features as $slug => $default ) : 
                            $display_name = isset($csv_names[$slug]) ? $csv_names[$slug] : ucwords( str_replace( '_', ' ', $slug ) );
                        ?>
                        <div class="vapt-feature-item">
                            <h4 title="<?php echo esc_attr($display_name); ?>"><?php echo esc_html( $display_name ); ?></h4>
                            <label class="switch">
                                <input type="checkbox" name="features[<?php echo esc_attr( $slug ); ?>]" value="1" <?php checked( VAPT_Features::is_enabled( $slug ) ); ?>>
                                <span class="slider round"></span>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <!-- Standard Table for few features -->
                    <table class="form-table">
                        <?php foreach( $all_features as $slug => $default ) : ?>
                        <tr>
                            <th scope="row" style="padding: 10px 0;"><?php echo esc_html( ucwords( str_replace( '_', ' ', $slug ) ) ); ?></th>
                            <td style="padding: 10px 0;">
                                <label class="switch">
                                    <input type="checkbox" name="features[<?php echo esc_attr( $slug ); ?>]" value="1" <?php checked( VAPT_Features::is_enabled( $slug ) ); ?>>
                                    <span class="slider round"></span>
                                </label>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                <?php endif; ?>
                
                <p>
                    <button type="button" id="vapt-save-features" class="button button-primary"><?php esc_html_e( 'Save Domain Features', 'vapt-security' ); ?></button>
                    <span id="vapt-features-msg" style="margin-left: 10px;"></span>
                </p>
            </form>
        </div>

        <!-- License Management & Generator in one row -->
        <div class="vapt-admin-row" style="display: flex; gap: 20px; margin-top: 20px;">
            
            <!-- License Management -->
            <div class="card" style="flex: 1; margin: 0; padding: 20px;">
                <h2><?php esc_html_e( 'License Management', 'vapt-security' ); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e( 'License Type', 'vapt-security' ); ?></th>
                        <td>
                            <select id="vapt-license-type" style="width: 100%;">
                                <option value="trial" <?php selected( $license_type, 'trial' ); ?>>Trial (7 days)</option>
                                <option value="demo" <?php selected( $license_type, 'demo' ); ?>>Demo Build (15 days)</option>
                                <option value="standard" <?php selected( $license_type, 'standard' ); ?> style="font-weight: bold;">Standard (30 days) [Default]</option>
                                <option value="pro" <?php selected( $license_type, 'pro' ); ?>>Pro (365 days)</option>
                                <option value="developer" <?php selected( $license_type, 'developer' ); ?>>Developer/Perpetual (Never)</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Expiry', 'vapt-security' ); ?></th>
                        <td><input type="text" id="vapt-license-expiry" value="<?php echo esc_attr( $expiry_date ); ?>" readonly class="regular-text" style="width: 100%;"></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Auto Renewal', 'vapt-security' ); ?></th>
                        <td>
                            <label class="switch">
                                <input type="checkbox" id="vapt-license-auto-renew" <?php checked( $license_auto_renew ); ?>>
                                <span class="slider round"></span>
                            </label>
                            <p class="description"><?php esc_html_e( 'Extend license automatically upon expiry.', 'vapt-security' ); ?></p>
                        </td>
                    </tr>
                    <?php if ( isset( $license['renewal_count'] ) ) : ?>
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Terms Renewed', 'vapt-security' ); ?></th>
                        <td>
                            <span class="badge" style="background: #2271b1; color: white; padding: 5px 10px; border-radius: 10px;">
                                <?php echo esc_html( $license['renewal_count'] ); ?>
                            </span>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th></th>
                        <td>
                            <button type="button" id="vapt-update-license" class="button button-secondary"><?php esc_html_e( 'Update License', 'vapt-security' ); ?></button>
                            <button type="button" id="vapt-renew-license" class="button button-secondary"><?php esc_html_e( 'Renew', 'vapt-security' ); ?></button>
                            <div id="vapt-license-msg" style="margin-top: 10px;"></div>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Locked Configuration Generator -->
            <div class="card" style="flex: 0 0 60%; margin: 0; padding: 20px;">
                <h2><?php esc_html_e( 'Locked Configuration Generator', 'vapt-security' ); ?></h2>
                <p class="description"><?php esc_html_e( 'Generate a portable configuration file locked to a specific domain pattern and customize plugin branding.', 'vapt-security' ); ?></p>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 20px;">
                    <!-- Column 1: Core Lock Settings -->
                    <div>
                        <h3 style="margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px;"><?php esc_html_e( 'Core Lock Settings', 'vapt-security' ); ?></h3>
                        <table class="form-table" style="margin-top: 0;">
                            <tr>
                                <th scope="row" style="width: 120px; padding: 10px 0;"><?php esc_html_e( 'Domain Pattern', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <input type="text" id="vapt-lock-domain" class="regular-text" placeholder="*.example.com" value="<?php echo esc_attr( $_SERVER['HTTP_HOST'] ); ?>" style="width: 100%;">
                                    <p class="description" style="font-size: 11px; margin-top: 5px;"><?php esc_html_e( 'Use * for wildcards (e.g., *.example.com).', 'vapt-security' ); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" style="padding: 10px 0;"><?php esc_html_e( 'Settings', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <label>
                                        <input type="checkbox" id="vapt-lock-include-settings" checked>
                                        <?php esc_html_e( 'Export current configuration', 'vapt-security' ); ?>
                                    </label>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- Column 2: White Labeling -->
                    <div>
                        <h3 style="margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px;"><?php esc_html_e( 'White Labeling', 'vapt-security' ); ?></h3>
                        <table class="form-table" style="margin-top: 0;">
                            <tr>
                                <th scope="row" style="width: 120px; padding: 10px 0;"><?php esc_html_e( 'Plugin Name', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <input type="text" id="vapt-wl-name" class="regular-text" placeholder="VAPT Security" style="width: 100%;">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" style="padding: 10px 0;"><?php esc_html_e( 'Slug', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <input type="text" id="vapt-wl-slug" class="regular-text" readonly style="width: 100%; background: #f0f0f1;">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" style="padding: 10px 0;"><?php esc_html_e( 'Author', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <input type="text" id="vapt-wl-author" class="regular-text" placeholder="Your Name" style="width: 100%;">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" style="padding: 10px 0;"><?php esc_html_e( 'Company', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <input type="text" id="vapt-wl-company" class="regular-text" placeholder="Your Company" style="width: 100%;">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" style="padding: 10px 0;"><?php esc_html_e( 'Description', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <textarea id="vapt-wl-description" class="regular-text" style="width: 100%; height: 60px;" placeholder="<?php esc_attr_e( 'Plugin description...', 'vapt-security' ); ?>"></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" style="padding: 10px 0;"><?php esc_html_e( 'Build Version', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <input type="text" id="vapt-wl-version" class="regular-text" value="1.0.0" style="width: 100%;">
                                    <div id="vapt-version-suggestion-wrapper" style="margin-top: 5px; font-size: 11px; display: none;">
                                        <?php esc_html_e( 'Suggested:', 'vapt-security' ); ?> 
                                        <button type="button" id="vapt-version-apply-suggestion" class="button-link" style="font-size: 11px; vertical-align: baseline;"></button>
                                    </div>
                                    <p class="description" style="font-size: 11px; margin-top: 5px;"><?php esc_html_e( 'Track per-domain build versions.', 'vapt-security' ); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" style="padding: 10px 0;"><?php esc_html_e( 'Min WP Version', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <input type="text" id="vapt-wl-wp-version" class="regular-text" placeholder="5.6" value="5.6" style="width: 100%;">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row" style="padding: 10px 0;"><?php esc_html_e( 'Min PHP Version', 'vapt-security' ); ?></th>
                                <td style="padding: 10px 0;">
                                    <input type="text" id="vapt-wl-php-version" class="regular-text" placeholder="7.4" value="7.4" style="width: 100%;">
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee; display: flex; gap: 10px; align-items: center;">
                    <button type="button" id="vapt-generate-locked-config" class="button button-primary" style="height: 40px; padding: 0 20px;"><?php esc_html_e( 'Generate Config File', 'vapt-security' ); ?></button>
                    <button type="button" id="vapt-generate-client-zip" class="button button-secondary" style="height: 40px; padding: 0 20px;">
                        <?php esc_html_e( 'Download Rebranded Zip', 'vapt-security' ); ?>
                    </button>
                    <div id="vapt-generate-msg" style="flex-grow: 1; font-weight: 500;"></div>
                </div>
            </div>

        </div>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    let timerInterval;

    function startOtpTimer() {
        let timeLeft = 120;
        $('#vapt-otp-timer').text(timeLeft);
        $('#vapt-otp-timer-container').show();
        $('#vapt-resend-otp').hide();
        
        clearInterval(timerInterval);
        timerInterval = setInterval(function() {
            timeLeft--;
            $('#vapt-otp-timer').text(timeLeft);
            if(timeLeft <= 0) {
                clearInterval(timerInterval);
                $('#vapt-otp-timer-container').hide();
                $('#vapt-resend-otp').show();
            }
        }, 1000);
    }

    // Auto-send OTP on load if not verified
    function autoSendOtp() {
        $.post(ajaxurl, {action:'vapt_send_otp'}, function(r){
            if(r.success) {
                $('#vapt-otp-message').html('<span style="color:green">'+r.data.message+'</span>');
                startOtpTimer();
            } else {
                $('#vapt-otp-message').html('<span style="color:red">'+r.data.message+'</span>');
            }
        });
    }

    if ($('#vapt-otp-input').length > 0) {
        autoSendOtp();
    }

    // Resend Logic
    $('#vapt-resend-otp').click(function(e){
        e.preventDefault();
        
        // Disable buttons temporarily
        $(this).prop('disabled', true);
        
        $.post(ajaxurl, {action:'vapt_send_otp'}, function(r){
             // Re-enable (for send btn)
            $('#vapt-send-otp').prop('disabled', false);

            if(r.success) {
                $('#vapt-otp-step-1').hide();
                $('#vapt-otp-step-2').show();
                $('#vapt-otp-message').html('<span style="color:green">'+r.data.message+'</span>');
                startOtpTimer();
            } else {
                $('#vapt-otp-message').html('<span style="color:red">'+r.data.message+'</span>');
            }
        });
    });

    $('#vapt-verify-otp').click(function(){
        $.post(ajaxurl, {
            action:'vapt_verify_otp', 
            otp: $('#vapt-otp-input').val()
        }, function(r){
            if(r.success) location.reload();
            else $('#vapt-otp-message').html('<span style="color:red">'+r.data.message+'</span>');
        });
    });

    // Save Features
    $('#vapt-save-features').click(function(){
        var data = $('#vapt-domain-features-form').serialize();
        $.post(ajaxurl, {
            action: 'vapt_save_domain_features',
            data: data
        }, function(r){
            if(r.success) $('#vapt-features-msg').html('<span style="color:green">'+r.data.message+'</span>');
            else $('#vapt-features-msg').html('<span style="color:red">'+r.data.message+'</span>');
        });
    });

    // License (Reuse endpoints)
    
    // Immediate Frontend Update
    var futureExpiries = <?php echo json_encode( $future_expiries ); ?>;
    
    function toggleRenewButton() {
        var isChecked = $('#vapt-license-auto-renew').is(':checked');
        $('#vapt-renew-license').prop('disabled', !isChecked);
    }

    // Initial state
    toggleRenewButton();

    $('#vapt-license-auto-renew').change(function(){
        toggleRenewButton();
    });

    $('#vapt-license-type').change(function(){
        var type = $(this).val();
        if ( futureExpiries[type] ) {
            $('#vapt-license-expiry').val( futureExpiries[type] );
        }
        
        // Developer Constraint
        if ( type === 'developer' ) {
            $('#vapt-license-auto-renew').prop('checked', false).prop('disabled', true);
        } else {
            $('#vapt-license-auto-renew').prop('disabled', false);
        }
        toggleRenewButton();
    });

    $('#vapt-update-license').click(function(){
        $.post(ajaxurl, {
            action:'vapt_update_license', 
            type:$('#vapt-license-type').val(),
            auto_renew: $('#vapt-license-auto-renew').is(':checked') ? 1 : 0
        }, function(r){
             if(r.success) {
                 $('#vapt-license-msg').html('<span style="color:green">'+r.data.message+'</span>');
                 if(r.data.expires_formatted) $('#vapt-license-expiry').val(r.data.expires_formatted);
             }
             else $('#vapt-license-msg').html('<span style="color:red">'+r.data.message+'</span>');
        });
    });
    // Locked Config Generator
    // Version suggestion logic
    function suggestNextVersion(current) {
        if (!current) return 'v1.0.0';
        var hasV = current.charAt(0).toLowerCase() === 'v';
        var version = hasV ? current.substring(1) : current;
        
        if (!version.match(/^\d+\.\d+\.\d+$/)) return hasV ? 'v1.0.0' : '1.0.0';
        
        var parts = version.split('.').map(Number);
        parts[2]++; // Default to patch bump
        return (hasV ? 'v' : '') + parts.join('.');
    }

    function updateVersionSuggestion(version) {
        if (version) {
            var next = suggestNextVersion(version);
            $('#vapt-version-apply-suggestion').text(next);
            $('#vapt-version-suggestion-wrapper').show();
        } else {
            $('#vapt-version-suggestion-wrapper').hide();
        }
    }

    $('#vapt-version-apply-suggestion').click(function() {
        var next = $(this).text();
        $('#vapt-wl-version').val(next);
        updateVersionSuggestion(next);
    });

    $('#vapt-lock-domain').on('change blur', function() {
        var domain = $(this).val();
        if (!domain) return;
        
        $.post(ajaxurl, {
            action: 'vapt_get_last_build_version',
            domain: domain,
            nonce: '<?php echo wp_create_nonce( "vapt_locked_config" ); ?>'
        }, function(r) {
            if (r.success && r.data.version) {
                updateVersionSuggestion(r.data.version);
            } else {
                updateVersionSuggestion('1.0.0');
            }
        });
    }).trigger('blur');

    $('#vapt-wl-version').on('input', function() {
        updateVersionSuggestion($(this).val());
    });

    $('#vapt-wl-name').on('input', function() {
        var name = $(this).val();
        var slug = name.toLowerCase()
            .replace(/[^\w\s-]/g, '') // Remove non-word chars
            .replace(/\s+/g, '-')     // Replace spaces with -
            .replace(/-+/g, '-')      // Replace multiple - with single -
            .trim();
        $('#vapt-wl-slug').val(slug);
    });

    $('#vapt-generate-locked-config').click(function(){
        var btn = $(this);
        btn.prop('disabled', true).text('<?php esc_html_e( 'Generating...', 'vapt-security' ); ?>');
        
        $.post(ajaxurl, {
            action: 'vapt_generate_locked_config',
            domain: $('#vapt-lock-domain').val(),
            include_settings: $('#vapt-lock-include-settings').is(':checked') ? 1 : 0,
            wl_name: $('#vapt-wl-name').val(),
            wl_slug: $('#vapt-wl-slug').val(),
            wl_description: $('#vapt-wl-description').val(),
            wl_author: $('#vapt-wl-author').val(),
            wl_company: $('#vapt-wl-company').val(),
            wl_version: $('#vapt-wl-version').val(),
            wl_wp_version: $('#vapt-wl-wp-version').val(),
            wl_php_version: $('#vapt-wl-php-version').val(),
            nonce: '<?php echo wp_create_nonce( "vapt_locked_config" ); ?>'
        }, function(r){
            btn.prop('disabled', false).text('<?php esc_html_e( 'Generate Config File', 'vapt-security' ); ?>');
            if(r.success) {
                $('#vapt-generate-msg').html('<span style="color:green">'+r.data.message+'</span>');
            } else {
                $('#vapt-generate-msg').html('<span style="color:red">'+r.data.message+'</span>');
            }
        });
    });

    // Client Zip Generator
    $('#vapt-generate-client-zip').click(function(){
        var btn = $(this);
        var originalText = btn.text();
        btn.prop('disabled', true).text('<?php esc_html_e( 'Building Zip...', 'vapt-security' ); ?>');
        
        $.post(ajaxurl, {
            action: 'vapt_generate_client_zip',
            domain: $('#vapt-lock-domain').val(),
            include_settings: $('#vapt-lock-include-settings').is(':checked') ? 1 : 0,
            wl_name: $('#vapt-wl-name').val(),
            wl_slug: $('#vapt-wl-slug').val(),
            wl_description: $('#vapt-wl-description').val(),
            wl_author: $('#vapt-wl-author').val(),
            wl_company: $('#vapt-wl-company').val(),
            wl_version: $('#vapt-wl-version').val(),
            wl_wp_version: $('#vapt-wl-wp-version').val(),
            wl_php_version: $('#vapt-wl-php-version').val(),
            nonce: '<?php echo wp_create_nonce( "vapt_locked_config" ); ?>' 
        }, function(r){
            btn.prop('disabled', false).text(originalText);
            if(r.success) {
                $('#vapt-generate-msg').html('<span style="color:green"><?php esc_html_e( 'Zip generated!', 'vapt-security' ); ?></span>');
                // Download
                var byteCharacters = atob(r.data.base64);
                var byteNumbers = new Array(byteCharacters.length);
                for (var i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                var byteArray = new Uint8Array(byteNumbers);
                var blob = new Blob([byteArray], {type: "application/zip"});
                
                var link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                link.download = r.data.filename;
                link.click();
            } else {
                $('#vapt-generate-msg').html('<span style="color:red">'+r.data.message+'</span>');
            }
        });
    });
});
</script>
